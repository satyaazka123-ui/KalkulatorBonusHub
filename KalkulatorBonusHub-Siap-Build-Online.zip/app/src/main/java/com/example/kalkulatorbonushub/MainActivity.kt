package com.example.kalkulatorbonushub

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import java.text.NumberFormat
import java.util.Locale

data class Tier(var start: Int, var end: Int?, var rate: Int)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bonus_settings", Context.MODE_PRIVATE) }
    private lateinit var tripInput: EditText
    private lateinit var result: TextView
    private lateinit var breakdown: TextView
    private lateinit var tiersBox: LinearLayout
    private val tierViews = mutableListOf<Triple<EditText, EditText, EditText>>()
    private val money = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        calculate()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 15f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(0xFF202124.toInt())
    }
    private fun field(hint: String, value: String = "") = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 15f
        inputType = InputType.TYPE_CLASS_NUMBER
        setSingleLine(true)
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = getDrawable(android.R.drawable.edit_text)
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; setOnClickListener { action() }
    }

    private fun loadTiers(): MutableList<Tier> {
        val defaults = listOf(Tier(1,15,0), Tier(16,20,3000), Tier(21,25,4500), Tier(26,null,6000))
        return defaults.mapIndexed { i, d ->
            Tier(prefs.getInt("s$i", d.start), prefs.getInt("e$i", d.end ?: -1).let { if (it < 0) null else it },
                prefs.getInt("r$i", d.rate))
        }.toMutableList()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFFF6F7F9.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(label("Kalkulator Bonus Hub", 24f).apply { setTypeface(null, Typeface.BOLD) })
        content.addView(label("Masukkan jumlah trip", 15f).apply { setPadding(0, dp(18), 0, dp(5)) })
        tripInput = field("Contoh: 35")
        content.addView(tripInput, LinearLayout.LayoutParams(-1, dp(52)))
        content.addView(button("Hitung bonus") { calculate() })
        result = label("Total bonus: Rp0", 22f).apply {
            setTypeface(null, Typeface.BOLD); setPadding(0, dp(16), 0, dp(8))
        }
        content.addView(result)
        breakdown = label("")
        content.addView(breakdown)
        content.addView(label("Pengaturan tarif dan rentang trip", 19f).apply {
            setTypeface(null, Typeface.BOLD); setPadding(0, dp(24), 0, dp(10))
        })
        content.addView(label("Ubah batas awal, batas akhir, dan tarif per trip. Kosongkan batas akhir untuk rentang tanpa batas."))
        tiersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(tiersBox)
        renderTiers()
        content.addView(button("Simpan tarif") { saveTiers() })
        content.addView(button("Kembalikan tarif awal") {
            prefs.edit().clear().apply()
            renderTiers()
            calculate()
            Toast.makeText(this, "Tarif awal dipulihkan", Toast.LENGTH_SHORT).show()
        })
        content.addView(label("Tarif tersimpan di perangkat dan tetap ada saat aplikasi ditutup.", 13f).apply {
            setPadding(0, dp(12), 0, dp(20))
        })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun renderTiers() {
        tiersBox.removeAllViews()
        tierViews.clear()
        loadTiers().forEachIndexed { i, t ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            row.addView(label("Tingkat ${i+1}", 14f).apply { setTypeface(null, Typeface.BOLD) })
            val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val start = field("Mulai", t.start.toString())
            val end = field("Sampai", t.end?.toString() ?: "")
            val rate = field("Rp/trip", t.rate.toString())
            listOf(start, end, rate).forEach { v ->
                fields.addView(v, LinearLayout.LayoutParams(0, dp(50), 1f).apply { setMargins(dp(2), dp(4), dp(2), dp(4)) })
            }
            row.addView(fields)
            tiersBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
            tierViews.add(Triple(start, end, rate))
        }
    }

    private fun saveTiers() {
        try {
            val editor = prefs.edit()
            tierViews.forEachIndexed { i, triple ->
                val s = triple.first.text.toString().toInt()
                val eText = triple.second.text.toString().trim()
                val e = if (eText.isEmpty()) -1 else eText.toInt()
                val r = triple.third.text.toString().toInt()
                require(s >= 1 && (e == -1 || e >= s) && r >= 0) { "Periksa batas trip dan tarif." }
                editor.putInt("s$i", s).putInt("e$i", e).putInt("r$i", r)
            }
            editor.apply()
            Toast.makeText(this, "Tarif berhasil disimpan", Toast.LENGTH_SHORT).show()
            calculate()
        } catch (ex: Exception) {
            Toast.makeText(this, "Input tidak valid. Periksa angka dan rentang trip.", Toast.LENGTH_LONG).show()
        }
    }

    private fun calculate() {
        val trips = tripInput.text.toString().toIntOrNull() ?: 0
        val tiers = loadTiers()
        var total = 0L
        val lines = mutableListOf<String>()
        tiers.forEach { t ->
            val end = t.end ?: trips
            val count = (minOf(trips, end) - t.start + 1).coerceAtLeast(0)
            val amount = count.toLong() * t.rate
            total += amount
            if (count > 0) lines.add("${t.start}–${if (t.end == null) "seterusnya" else t.end}: $count × ${money.format(t.rate)} = ${money.format(amount)}")
        }
        result.text = "Total bonus: ${money.format(total)}"
        breakdown.text = if (lines.isEmpty()) "Belum ada trip yang masuk rentang bonus." else lines.joinToString("\n")
    }
}
